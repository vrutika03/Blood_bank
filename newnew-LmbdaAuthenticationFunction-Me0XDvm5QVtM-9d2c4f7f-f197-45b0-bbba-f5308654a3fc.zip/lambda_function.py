
import boto3
import json
import os

client = boto3.client('cognito-idp')

def register(event):
    email = event['email']
    password = event['password']
    phone_number = event.get('phone_number')

    user_attributes = [
        {
            'Name': 'email',
            'Value': email
        }
    ]

    if phone_number:
        user_attributes.append({
            'Name': 'phone_number',
            'Value': phone_number
        })

    response = client.sign_up(
        ClientId=os.getenv("CLIENT_ID"),
        Username=email,
        Password=password,
        UserAttributes=user_attributes
    )

    return {'message': 'User registered successfully!'}

def login(event):
    email = event['email']
    password = event['password']

    response = client.initiate_auth(
        ClientId=os.getenv("CLIENT_ID"),
        AuthFlow='USER_PASSWORD_AUTH',
        AuthParameters={
            'USERNAME': email,
            'PASSWORD': password
        }
    )

    return {'access_token': response['AuthenticationResult']['AccessToken']}

def confirm(event):
    email = event['email']
    confirmation = event['confirmation']

    response = client.confirm_sign_up(
        ClientId=os.getenv("CLIENT_ID"),
        Username=email,
        confirmation=confirmation
    )

    return {'message': 'User confirmed successfully!'}

def lambda_handler(event, context):
    action = event['action']

    if action == 'register':
        result = register(event)
    elif action == 'login':
        result = login(event)
    elif action == 'confirm':
        result = confirm(event)
    else:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid action'})
        }

    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    }

    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps(result)
    }

 
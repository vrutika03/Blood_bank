import json
import boto3
import os

def lambda_handler(event, context):
   
    dname = event['dname']
    bloodbag = event['bloodbag']
    quantity = event['quantity']
    email = event['email']
    bloodgroup = event['bloodgroup']
    
    message = f"""
        Donor Name: {dname}
        Blood Bag ID: {bloodbag}
        Quantity: {quantity}
        Email: {email}
        Blood Group: {bloodgroup}
    """
   
    sns = boto3.client('sns')
    response = sns.publish(
        TopicArn=os.getenv("SNS_TOPIC_ARN"),
        Message=message,
        Subject='Blood Request Information'
    )
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    }
    return {
        'statusCode': 200,
        'headers': headers,
        'body': json.dumps('Blood request information sent via email.')
    }

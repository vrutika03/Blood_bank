import boto3
import json
import 

def lambda_handler(event, context):
   
    email = event['email']
   
    message = {
        'default': 'New blood donation location available.',
        'email': f'To: {email}\nSubject: New blood donation location available\n\nHello,\n\nThere is a new blood donation location available. Please find the details below:\n\nLocation: Canadian Blood Services\nAddress: 7071 Bayers Rd Unit 252, Halifax, NS B3L 2C2\nDate: 26th May 2023\nTime: 10 PM to 6 PM\n\nLocation:Central Hospital\nAddress:123 Main Street, Toronto ,CN\nDate: 05th December 2023\nTime: 10 PM to 6 PM\n\nLocation: City Clinic\nAddress: 456 Elm Street, Anytown USA\nDate: 15th April 2023\nTime: 10 PM to 6 PM \n\nThank you for your support!\n\nBest regards,\nBlood bank Management '
    }
   
    message_json = json.dumps(message)
    
    sns_client = boto3.client('sns')
   
    topic_arn = os.getenv("SNS_TOPIC_ARN")
    
    response = sns_client.publish(
        TopicArn=topic_arn,
        Message=message_json,
        MessageStructure='json',
        MessageAttributes={
            'email': {
                'DataType': 'String',
                'StringValue': email
            }
        }
    )
    
    print(response)

    return {
        'statusCode': 200,
        'body': 'Message sent to SNS topic for email: ' + email
    }

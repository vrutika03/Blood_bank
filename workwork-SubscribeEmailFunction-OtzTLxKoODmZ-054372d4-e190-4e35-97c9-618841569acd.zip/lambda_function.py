import boto3
import 

def lambda_handler(event, context):
    
    sns_client = boto3.client('sns')
    
    email = event['email']
    
    topic_arn = os.getenv("SNS_TOPIC_ARN")
    
    response = sns_client.subscribe(
        TopicArn=topic_arn,
        Protocol='email',
        Endpoint=email
    )
    
    print(response)
    
    return {
        'statusCode': 200,
        'body': 'Subscription request sent for email: ' + email
    }

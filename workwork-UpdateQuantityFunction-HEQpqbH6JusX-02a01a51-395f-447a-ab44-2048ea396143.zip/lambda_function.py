import json
import boto3
from decimal import Decimal

def lambda_handler(event, context):
   
    quantity = Decimal(str(event['quantity']))
    bloodbag = event['bloodbag']
 
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('totalblood')
 
    response = table.get_item(Key={'bloodbag': bloodbag})
  
    item = response['Item']
    available_quantity = Decimal(str(item['quantity']))
    
    if quantity > available_quantity:
        return {
            'statusCode': 400,
            'body': 'Requested quantity exceeds available quantity'
        }
    elif quantity <= 0:
        return {
            'statusCode': 400,
            'body': 'Invalid quantity'
        }
    updated_quantity = available_quantity - Decimal(str(quantity))
    
    table.update_item(
        Key={'bloodbag': bloodbag},
        UpdateExpression='SET quantity = :val',
        ExpressionAttributeValues={
            ':val': updated_quantity
        }
    )
    
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
    }
    
    return {
        'statusCode': 200,
        'headers': headers,
        'body': 'Quantity updated successfully'
    }

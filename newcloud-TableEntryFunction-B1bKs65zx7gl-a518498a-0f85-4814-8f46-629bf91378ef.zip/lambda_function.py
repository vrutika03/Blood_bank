# import boto3
# import json
# from decimal import Decimal

# def lambda_handler(event, context):
#     # Create a DynamoDB client
#     dynamodb = boto3.resource('dynamodb')
    
#     # Get the table
#     table = dynamodb.Table('totalblood')
    
#     # Fetch the data from the table
#     response = table.scan()
#     items = response['Items']
    
#     # Convert Decimal objects to float
#     for item in items:
#         for key in item:
#             if isinstance(item[key], Decimal):
#                 item[key] = float(item[key])
    
#     # Return a response
#     response = {
#         'statusCode': 200,
#         'body': json.dumps(items)
#     }
    
#     return response


import boto3
import json

def lambda_handler(event, context):
    
    dynamodb = boto3.resource('dynamodb')
    
    table = dynamodb.Table('totalblood')
    
   
    bloodgroup = event['body-json']['bloodgroup']
    dname = event['body-json']['dname']
    expiry = event['body-json']['expiry']
    bloodbag = event['body-json']['bloodbag']
    quantity = event['body-json']['quantity']
     
    print(bloodbag);
    print(expiry);
    print(dname);
    
    print(quantity);
     
    table.put_item(
        Item={
            'bloodgroup': bloodgroup,
            'dname': dname,
            'expiry': expiry,
            'bloodbag': bloodbag,
            'quantity': quantity
        }
    )

    response = {
        'statusCode': 200,
        'body': json.dumps('Item added to DynamoDB table')
    }
    
    return response